from db import db

# This class takes care of storing followups sent to the client.

class FollowUpModel(db.Model):
    __tablename__ = 'follow_up'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String, unique=False, nullable=False)
    body = db.Column(db.String, unique=False,  nullable=False)
    date = db.Column(db.Date, nullable=False)

    councilor_id = db.Column(db.Integer, db.ForeignKey("user.id", ondelete="SET NULL"), nullable=False)

    councilor = db.relationship("UserModel", back_populates="follow_ups")
    clients = db.relationship("ClientModel", back_populates="follow_ups", secondary="client_follow_up")