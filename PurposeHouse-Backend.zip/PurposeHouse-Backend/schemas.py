from marshmallow import Schema, fields

class PlainClientSchema(Schema):
    id = fields.Int(dump_only=True)
    first_name = fields.Str(required=True)
    last_name = fields.Str(required=True)
    title = fields.Str(required=True)
    email = fields.Str(required=True)

class PlainAppointmentSchema(Schema):
    id = fields.Int(dump_only=True)
    date = fields.Str(required=True)
    description = fields.Str()
    note = fields.Str()
    feedback = fields.Str()

    councilor_id = fields.Int()

class PlainUserSchema(Schema):
    id = fields.Int(dump_only=True)
    first_name = fields.Str(required=True)
    last_name = fields.Str(required=True)
    title = fields.Str(required=True)
    role = fields.Str(dump_only=True)

    email = fields.Str(required=True)
    password = fields.Str(required=True, load_only=True)

class PlainFollowUpSchema(Schema):
    id = fields.Int(dump_only=True)
    title = fields.Str(required=True)
    body = fields.Str(required=True)
    date = fields.Str(dump_only=True)

    councilor_id = fields.Int(required=True)

class PlainAuthorizationSchema(Schema):
    Authorization = fields.Str(required=True, load_only=True)

class LoginSchema(Schema):
    access_token = fields.Str(dump_only=True)
    refresh_token = fields.Str(dump_only=True)

    user = fields.Nested(PlainClientSchema(), dump_only=True)

    email = fields.Str(load_only=True)
    password = fields.Str(load_only=True)

class RegisterSchema(LoginSchema):
    message = fields.Str(dump_only=True)

class RefreshSchema(Schema):
    access_token = fields.Str(dump_only=True)

class ClientSchema(PlainClientSchema):
    # appointments = fields.List(fields.Nested(PlainAppointmentSchema(), dump_only=True))
    councilors = fields.List(fields.Nested(PlainUserSchema(), dump_only=True))

class UserSchema(PlainUserSchema):
    appointments = fields.List(fields.Nested(PlainAppointmentSchema(), dump_only=True))
    clients = fields.List(fields.Nested(PlainClientSchema(), dump_only=True))

class AppointmentSchema(PlainAppointmentSchema):
    clients = fields.List(fields.Nested(PlainClientSchema(), dump_only=True))
    councilor = fields.Nested(PlainUserSchema(), dump_only=True)

class UserAndClientSchema(Schema):
    message = fields.Str()
    user = fields.Nested(UserSchema)
    client = fields.Nested(ClientSchema)

class FollowUpSchema(PlainFollowUpSchema):
    clients = fields.List(fields.Nested(PlainClientSchema(), dump_only=True))
    councilor = fields.Nested(PlainUserSchema(), dump_only=True)
