import datetime
from flask import request, jsonify
from flask.views import MethodView
from flask_smorest import Blueprint, abort
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from sqlalchemy import or_, func

from passlib.hash import pbkdf2_sha256
from flask_jwt_extended import create_access_token, create_refresh_token, get_jwt, get_jwt_identity, jwt_required
from permissions import protect

from db import db
from models import UserModel, ClientModel, UserClientModel
from schemas import PlainUserSchema, RegisterSchema, LoginSchema, RefreshSchema, PlainAuthorizationSchema, ClientSchema, AppointmentSchema, FollowUpSchema
from resources.appointment import appointmentQuerier
from resources.client import clientQuerier
from resources.follow_up import followUpQuerier

blp = Blueprint("Users", "users", description="Operations on users")

@blp.route("/register")
class RegisterCouncilor(MethodView):
    @blp.arguments(PlainUserSchema)
    @blp.response(201, RegisterSchema, description="councilor successfully registered.")
    @blp.alt_response(422, description="Required fields for registering councilor not included.")
    @blp.alt_response(400, description="Duplicate email included.")
    @blp.alt_response(500, description="Server error in saving the councilor.")
    def post(self, councilor_data):
        """Create a new councilor.
        
        This route create a new 'user' object in the database. This users will be classified as a councilor,
        not an admin, so they will have limited permissions."""
        #1) First, check if the councilor email is on the whitelist. 

        #2) Create the user model from the councilor and append the needed information.
        councilor = UserModel(
            first_name = councilor_data["first_name"],
            last_name = councilor_data["last_name"],
            title =  councilor_data["title"],
            role = "councilor",

            email = councilor_data["email"],
            password = pbkdf2_sha256.hash(councilor_data["password"])
        )

        #3) Try to save the user model to the database.
        try:
            db.session.add(councilor)
            db.session.commit()
        except IntegrityError:
            abort(400, message="Email must be unique.")
        except SQLAlchemyError:
            abort(500, message="There was an error in saving the councilor to the database.")

        #4) Get the councilor from the database so we can get their ID.
        councilor = UserModel.query.filter(UserModel.email == councilor_data["email"]).first()

        #5) Create a JWT for the councilor so they can access their routes.
        access_token = create_access_token(identity=councilor.id, fresh=True)
        refresh_token = create_refresh_token(identity=councilor.id)

        return {"message": "councilor created successfully.", "access_token": access_token, "refresh_token": refresh_token, "user": councilor}, 201

@blp.route("/login")
class LoginUser(MethodView):
    @blp.arguments(LoginSchema)
    @blp.response(200, LoginSchema)
    def post(self, login_data):
        """Logs in a user
        
        This route logs in both councilors and admins. It will return the user information as well as an access token and refresh token"""
        user = UserModel.query.filter(UserModel.email == login_data["email"]).first()

        if user and pbkdf2_sha256.verify(login_data["password"], user.password):
            access_token = create_access_token(identity=user.id, fresh=True)
            refresh_token = create_refresh_token(identity=user.id)
            return {"access_token": access_token, "refresh_token": refresh_token, "user": user}

        abort(401, message="Invalid credentials.")

@blp.route("/refresh")
class TokenRefresh(MethodView):
    @jwt_required(refresh=True)
    @blp.response(200, RefreshSchema)
    def post(self):
        """Get token refreshed

        This route creates a refresh token for the logged in user."""
        current_user = get_jwt_identity()
        new_token = create_access_token(identity=current_user, fresh=False)
        return {"access_token": new_token}

@blp.route("/admin")
class Admin(MethodView):
    @blp.arguments(PlainUserSchema)
    @blp.response(201, LoginSchema, description="Admin created successfully.")
    @blp.alt_response(422, description="Required fields for registering councilor not included.")
    @blp.alt_response(400, description="Duplicate email included.")
    @blp.alt_response(500, description="Server error in saving the councilor.")
    def post (self, admin_data):
        """Create an admin.
        
        This route creates a new user object, in this case classified as an admin. This user will have additional permissions."""
        # Verify that the person creating a new admin is an admin and that
        # they exist.
        # PROTECT IS DISABLED FOR CHECKPOINT Beta
        # protect(requestor_id=get_jwt_identity(), allowed_roles=["admin"])

        # Create the admin user model.
        admin = UserModel(
            first_name = admin_data["first_name"],
            last_name = admin_data["last_name"],
            title =  admin_data["title"],
            role = "admin",

            email = admin_data["email"],
            password = pbkdf2_sha256.hash(admin_data["password"])
        )

        #3) Try to save the user model to the database.
        try:
            db.session.add(admin)
            db.session.commit()
        except IntegrityError:
            abort(400, message="Email must be unique.")
        except SQLAlchemyError:
            abort(500, message="There was an error in saving the admin to the database.")

        #4) Get the admin from the database so we can get their ID.
        admin = UserModel.query.filter(UserModel.email == admin_data["email"]).first()

        #4) Create a JWT for the councilor so they can access their routes.
        access_token = create_access_token(identity=admin.id, fresh=True)
        refresh_token = create_refresh_token(identity=admin.id)

        return { "message": "Admin created successfully.", "user": admin, "access_token": access_token, "refresh_token": refresh_token}, 201

@blp.route("/councilor/<int:user_id>/client/<int:client_id>")
class LinkClientToCouncilor(MethodView):
    @jwt_required(fresh=True)
    @blp.response(201, description="Client linked successfully.")
    @blp.alt_response(404, description="Councilor or client not found.")
    @blp.alt_response(500, description="An error occurred in saving the link to the database.")
    def post(self, user_id, client_id):
        """Link Client to User
        
        This route will link a client to a specific councilor or admin. This will allow non-admin councilors
        to be able to access their information."""
        user = UserModel.query.get_or_404(user_id)
        client = ClientModel.query.get_or_404(client_id)

        user.clients.append(client)
        try:
            db.session.add(client)
            db.session.commit()
        except IntegrityError:
            abort(400, message="Client is already linked to this councilor.")
        except SQLAlchemyError:
            abort(500, message="There was an error linking this client to the councilor.")

        return {"message": "Client {} linked to councilor {}.".format(client_id, user_id)}, 200

    @jwt_required(fresh=True)
    @blp.response(200, description="Client unassociated successfully.")
    @blp.alt_response(404, description="User, client, or user-client link was not found.")
    @blp.alt_response(500, description="An error occurred in deleting the link from the database.")
    def delete(self, user_id, client_id):
        """Delete link between Client and User
        
        This route deletes the link between a Client and a councilor or admin. Councilors will no longer
        be allowed to access their information."""
        # This line verifies that the user and client are actually linked.
        user_client = UserClientModel.query.get_or_404([user_id, client_id])

        user = UserModel.query.get_or_404(user_id)
        client = ClientModel.query.get_or_404(client_id)

        user.clients.remove(client)
        try:
            db.session.add(client)
            db.session.commit()
        except SQLAlchemyError:
            abort(500, message="There was an error in unlinking this client from the councilor.")

        return {"message": "Client {} unlinked from councilor {}.".format(client_id, user_id)}, 200
    
@blp.route("/councilor/appointment")
class CouncilorAppointmentLists(MethodView):
    @jwt_required()
    @blp.response(200, AppointmentSchema(many=True), description="Returns and searches all appointments of the logged-in councilor with pagination.")
    @blp.alt_response(500, description="Returns if there was an error in executing the search query.")
    def get(self):
        """Search user's own appointments
        
        This route will search through all appointments that the councilor or admin has created. This will be changed
        to search all appointments associated with the councilor/admin's clients.
        This route takes any of a pre-defined set of query parameters and filters queries based on them.
        Query parameters are currently fully listed and described in the Postman Documentation."""
        # Get the search params into a mutable dictionary.
        args = {**request.args}

        # Add the councilor ID as an argument.
        args["councilor_id"] = get_jwt_identity()

        try:
            appointments = appointmentQuerier(args)
        except SQLAlchemyError as e:
            # print(e)
            abort(500, "There was an error in executing the search query.")

        return appointments

@blp.route("/councilor/client")
class CouncilorClientLists(MethodView):
    @jwt_required()
    @blp.response(200, ClientSchema(many=True), description="Returns and searches all appointments of the logged-in councilor with pagination.")
    @blp.alt_response(500, description="Returns if there was an error in executing the search query.")
    def get(self):
        """Search user's own clients
        
        This route will search through all clients that are linked to the councilor or admin.
        This route takes any of a pre-defined set of query parameters and filters queries based on them.
        Query parameters are currently fully listed and described in the Postman Documentation."""
        # Get the search params into a mutable dictionary.
        args = {**request.args}

        # Add the councilor ID as an argument.
        args["councilor_id"] = get_jwt_identity()

        try:
            clients = clientQuerier(args)
        except SQLAlchemyError as e:
            abort(500, "There was an error in executing the search query.")

        return clients

"""@blp.route("/councilor/client/day")
class GetClientsUsuallyInteractedWith(MethodView):
    @jwt_required()
    @blp.response(200, ClientSchema(many=True), description="Returns all clients that a councilor usually associates with on a given day")
    @blp.alt_response(500, description="Returns if there was an error in executing the search query.")
    def get(self):
        #1) Get the councilor ID from the jwt.
        councilor_id = get_jwt_identity()

        #2) Get the current day of the week.
        current_day = datetime.date.weekday(datetime.date.today())
       
        #3) Layout the joins for the query.
        query = db.session.query(ClientModel).join(UserClientModel).join(ClientAppointmentModel).join(AppointmentModel)

        #4) Append the filter to filter clients that have any appointment on a specific day.
        filters = []
        filters.append(func.strftime("%w", getattr(AppointmentModel, "date")) == current_day)

        #X) Run the query.
        clients = query.filter(*filters).all()

        #X+1) Return the information.
        return clients, 200"""


@blp.route("/councilor/followup")
class CouncilorFollowUpLists(MethodView):
    @jwt_required()
    @blp.response(200, FollowUpSchema(many=True), description="Returns and searches all followups of the logged-in councilor with pagination.")
    @blp.alt_response(500, description="Returns if there was an error in executing the search query.")
    def get(self):
        """Search user's own follow-ups
        
        This route will search through all follow-ups that are linked to the councilor or admin.
        In the future, this route will be updated to search through all follow-ups associated with 
        the client's users.
        This route takes any of a pre-defined set of query parameters and filters queries based on them.
        Query parameters are currently fully listed and described in the Postman Documentation."""
        #1) Get the search params into a mutable dictionary.
        args = {**request.args}

        #2) Add the councilor ID as an argument.
        args["councilor_id"] = get_jwt_identity()

        try:
            follow_ups = followUpQuerier(args)
        except SQLAlchemyError as e:
            print(e)
            abort(500, "There was an error in executing the search query.")

        return follow_ups

        