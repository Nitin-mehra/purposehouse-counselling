from db import db

class ClientAppointmentModel(db.Model):
    __tablename__ = "client_appointment"

    client_id = db.Column(db.Integer, db.ForeignKey("client.id"), primary_key=True)
    appointment_id = db.Column(db.Integer, db.ForeignKey("appointment.id"), primary_key=True)