import React, { useEffect, useState } from 'react';
import bc from '../layout/Images/i1.png';
import axios from 'axios'
import { Link } from 'react-router-dom';
import AppoinmentDashboard from '../appointment_ui/appoinmentDashboard';
import "./Home.css";
import "./Clients.css";

const Appointments = () => {
    const [ searchText, setSearchText ] = useState("");
    const [ searchedResult, setSearchedResult ] = useState([]);

    const [ isAdvanceFilterClicked, setIsAdvancedFilterClicked ] = useState(false);

    const [ emailFilterStatus, setEmailFilterStatus ] = useState(false)
    const [ firstNameStatus, setFirstNameFilterStatus ] = useState(false)
    const [ lastNameFilterStatus, setLastNameFilterStatus ] = useState(false)

    let access_token = sessionStorage.getItem('access_token');

    let delay;

    const fetchAppoinments = async()=> {
      console.log('call Api',searchText)
      let isAnyOfEmailFirstNameOrLastNameEmpty = true
      let params = {}
      if(emailFilterStatus){
          params['email'] = searchText;
          isAnyOfEmailFirstNameOrLastNameEmpty = false
      }

    //   if(isAnyOfEmailFirstNameOrLastNameEmpty){
    //       params['appointment_includes'] = searchText
    //   }

      await axios.get("/appointment",{ params: params,headers: {"Authorization" : `Bearer ${access_token}`} })
        .then(res => {
            if(res.status === 200){
                console.log("res",res)
                setSearchedResult(res.data)
            }
        })
        .catch(err => console.log("error in fetching clients"))
    }

      useEffect(() => {
        fetchAppoinments()
      },[])
    
      useEffect(() => {
        if(searchText){
            delay = setTimeout(() => {
                if(searchText)fetchAppoinments()
              }, 1000)
          
              return () => clearTimeout(delay)
        }
        else{
            fetchAppoinments()
        }
         
      }, [searchText])
    
      const keyDown = (e)=>{
        if (e.key === "Enter") {
          clearTimeout(delay)
          fetchAppoinments()
          console.log('keyDown press and ready for api call')
        }
      }

    return (
        <div className="container">
          
          <div className='dashboard-menus-main'>
                    <div>
                        <p className='counciler-counciler'>Counciler:</p>
                         <div className='counclier-static-left'>
                            <img src="/download-icon.svg" height={20} width={20} className="counciler-static-arror-icon" />
                            <button className='counciler-static-btn'>YOU</button>
                         </div>
                        
                    </div>

                    <div className='menubar-searchbar-main'>
                        <input type="text" placeholder=' Search Name, Email, First Name, Last Name'
                            value={searchText} onChange={(e) => setSearchText(e.target.value)}
                            onKeyDown={keyDown} className="search-bar-input"
                        />
                        <p onClick={() => setIsAdvancedFilterClicked(!isAdvanceFilterClicked)}
                           className={isAdvanceFilterClicked ? "advance-filter-active" : "advance-filter"}
                        >
                            Advance Filters
                        </p>
                        {isAdvanceFilterClicked && (
                            <div className='advance-filer-main'>
                                <input type="checkbox" 
                                    className='advance-filter-input' 
                                    id="email" 
                                    name="email"
                                    value={emailFilterStatus} 
                                    onChange={(e) =>  setEmailFilterStatus(e.target.checked) } />
                                <label for="email" className='filter-menu-input-label'> Email</label>
            
                                <input type="checkbox" 
                                    className='advance-filter-input' 
                                    id="firstName" 
                                    name="firstName" 
                                    value={firstNameStatus}
                                    onChange={(e) =>  setFirstNameFilterStatus(e.target.checked)}
                                    />
                                <label for="firstName" className='filter-menu-input-label'> First Name</label>
            
                                <input type="checkbox" 
                                    className='advance-filter-input' 
                                    id="lastName" 
                                    name="lastName" 
                                    value={lastNameFilterStatus}
                                    onChange={(e) =>  setLastNameFilterStatus(e.target.checked)}
                                    />
                                <label for="lastName" className='filter-menu-input-label'> Last Name</label>
                            </div>
                        )}
                        
                    </div>

                    <div>
                        <div >
                            <Link to="/appointmentCreate">
                                <button className="create">+Appointment</button>
                            </Link>
                        </div>
                    </div>
                </div>

            <div>
            
            <AppoinmentDashboard searchedResult={searchedResult}/>
            </div>
        </div>
    )
}

export default Appointments;