from db import db

class ClientFollowUpModel(db.Model):
    __tablename__ = 'client_follow_up'

    client_id = db.Column(db.Integer, db.ForeignKey("client.id"), primary_key=True)
    follow_up_id = db.Column(db.Integer, db.ForeignKey("follow_up.id"), primary_key=True)