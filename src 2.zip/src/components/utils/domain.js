const Domain = () => {
    return 'https://purposehouse.onrender.com/'
}

export default Domain;