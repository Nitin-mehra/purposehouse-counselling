from flask import request
from flask.views import MethodView
from flask_smorest import Blueprint, abort
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from sqlalchemy import or_, func

from flask_jwt_extended import jwt_required, get_jwt_identity
from permissions import protect

from db import db
from models import AppointmentModel, ClientModel, ClientAppointmentModel
from schemas import PlainAppointmentSchema, AppointmentSchema, PlainAuthorizationSchema

import datetime

blp = Blueprint("Appointments", "appointments", description="Operations on apppointments")

@blp.route("/appointment")
class AppointmentList(MethodView):
    @jwt_required()
    @blp.response(200, AppointmentSchema(many=True))
    def get(self):
        """Searches all clients. Admin Only.

        This route takes any of a pre-defined set of query parameters and filters queries based on them.
        Query parameters are currently fully listed and described in the Postman Documentation.
        """
        # Restrict this role to admins only.
        protect(requestor_id=get_jwt_identity(), allowed_roles=['admin'])

        # This route includes pagination, which means that you can specify
        # the page and number of clients.
        args = request.args
        return appointmentQuerier(args)

    @jwt_required()
    @blp.arguments(PlainAppointmentSchema, description="Creates an appointment.")
    @blp.response(201, PlainAppointmentSchema, description="Appointment successfully created.")
    @blp.alt_response(422, description="Required fields for creating appointment not included.")
    @blp.alt_response(500, description="Server error in saving the appointment.")
    def post(self, appointment_data):
        """Create an appointment
        
        Creates an appointment which is automatically associated with the user_id"""
        # RESTRICT COUNCILORS TO ONLY CREATE APPOINTMENTS FOR THEMSELVES

        #1) Set the councilor ID based on whether it was passed or not.
        if "councilor_id" in appointment_data:
            councilor_id = appointment_data["councilor_id"]
        else:
            councilor_id = get_jwt_identity()

        #2) Create the appointment model
        appointment = AppointmentModel (
            date = datetime.datetime.strptime(appointment_data["date"], '%Y-%m-%d'),
            description = appointment_data["description"],
            note = appointment_data["note"],
            feedback = appointment_data["feedback"],

            councilor_id = councilor_id
        )

        #3) Try to save the appointment model to the database.
        try:
            db.session.add(appointment)
            db.session.commit()
        except SQLAlchemyError:
            abort(500, message="There was an error in saving the appointment to the database.")

        return appointment, 201

@blp.route("/appointment/<int:appointment_id>")
class Appointment(MethodView):
    @jwt_required()
    @blp.response(200, AppointmentSchema, description="Returns the appointment associated with this ID.")
    @blp.alt_response(404, description="The appointment was not found.")
    def get(self, appointment_id):
        """Get appointment by ID
        
        Gets appointment information by the appointment ID"""
        # RESTRICT COUNCILORS TO ONLY GET APPOINTMENTS FROM THEIR OWN CLIENTS

        appointment = AppointmentModel.query.get_or_404(appointment_id)
        return appointment

    @jwt_required()
    @blp.arguments(PlainAppointmentSchema, description="Updated appointment information.")
    @blp.response(200, PlainAppointmentSchema, description="Appointment successfully updated.")
    @blp.alt_response(201, description="Appointment successfully created.")
    @blp.alt_response(422, description="Required fields for creating appointment not included.")
    @blp.alt_response(500, description="Server error in saving the apppointment.")
    def put(self, appointment_data, appointment_id):
        """Update or create a appointment
        
        This route is designed to update an appointment, however in the case that the requested
        appointment ID does not exist, it will create the appointment."""
        # Set the councilor ID based on whether it was passed or not.
        if "councilor_id" in appointment_data:
            councilor_id = appointment_data["councilor_id"]
        else:
            councilor_id = get_jwt_identity()
        
        appointment = AppointmentModel.query.get(appointment_id)
        if appointment:
            appointment.date = datetime.datetime.strptime(appointment_data["date"], '%Y-%m-%d')
            appointment.description = appointment_data["description"]
            appointment.note = appointment_data["note"]
            appointment.feedback = appointment_data["feedback"]

            appointment.councilor_id = councilor_id
        else:
            appointment = AppointmentModel (
            date = datetime.datetime.strptime(appointment_data["date"], '%Y-%m-%d'),
            description = appointment_data["description"],
            note = appointment_data["note"],
            feedback = appointment_data["feedback"],

            client_id = appointment_data["client_id"],
            councilor_id = councilor_id
            )

        # Try to update / create the appointment.
        try:
            db.session.add(appointment)
            db.session.commit()
        except SQLAlchemyError:
            abort(500, message="There was an error in saving or updating the client to the database.")

        return appointment
    
    # Deletes an appointment from the database.
    @jwt_required()
    @blp.response(200, description="Appointment deleted successfully.")
    @blp.alt_response(404, description="Appointment not found.")
    @blp.alt_response(500, description="Server error in deleting the appointment.")
    def delete(self, appointment_id):
        """Delete an appointment
        
        Deletes an appointment from the database."""
        #1) Abort the request if the user does not exist and restrict to councilor and admin.
        user = protect(requestor_id=get_jwt_identity(), allowed_roles=["admin", "councilor"])

        #2) Get the appointment from the database.
        appointment = AppointmentModel.query.get_or_404(appointment_id)

        #3) Delete the appointment from the database.
        try:
            db.session.delete(appointment)
            db.session.commit()
        except:
            abort(500, message="There was an error deleting the follow-up from the database.")
        return { "message": "Appointment deleted."}, 200

@blp.route("/appointment/<int:appointment_id>/client/<int:client_id>")
class LinkClientToAppointment(MethodView):
    @jwt_required(fresh=True)
    @blp.response(201, description="Client linked to appointment successfully.")
    @blp.alt_response(404, description="Appointment or client not found.")
    @blp.alt_response(400, description="The appointment is already linked to the client.")
    @blp.alt_response(500, description="An error occurred in saving the link to the database.")
    def post (self, appointment_id, client_id): 
        """Link appointment to client
        
        This route links an appointment to a client."""
        appointment = AppointmentModel.query.get_or_404(appointment_id)
        client = ClientModel.query.get_or_404(client_id)

        appointment.clients.append(client)
        try:
            db.session.add(client)
            db.session.commit()
        except IntegrityError:
            abort(400, message="Client is already linked to this appointment.")
        except SQLAlchemyError:
            abort(500, message="There was an error in linking this client to the appointment.")

        return {"message": "Appointment {} linked to client {}.".format(appointment_id, client_id)}, 200

    @jwt_required(fresh=True)
    @blp.response(200, description="Client unassociated successfully.")
    @blp.alt_response(404, description="Appointment, client, or appointment-client link was not found.")
    @blp.alt_response(500, description="An error occurred in deleting the link from the database.")
    def delete(self, appointment_id, client_id):
        """Delete link between client and appointment
        
        This route deletes the link between a client and an appointment."""
        # This line verifies that the appointment and client are actually linked.
        appointment_client = ClientAppointmentModel.query.get_or_404([client_id, appointment_id])

        appointment = AppointmentModel.query.get_or_404(appointment_id)
        client = ClientModel.query.get_or_404(client_id)

        appointment.clients.remove(client)
        try:
            db.session.add(client)
            db.session.commit()
        except SQLAlchemyError:
            abort(500, message="There was an error in unlinking this client from the appointment.")

        return {"message": "Appointment {} unlinked from client {}.".format(appointment_id, client_id)}, 200

# This is a large filter for the appointments which essentially filters on all the attributes.
def appointmentQuerier(args):
    filters = []

    # Create the query
    query = db.session.query(AppointmentModel)

    keys = args.keys()
    if "councilor_id" in keys:
        filters.append(getattr(AppointmentModel, "councilor_id") == args["councilor_id"])
    if "start_date" in keys:
        filters.append(getattr(AppointmentModel, "date") >= func.DATE(args["start_date"]))
    if "end_date" in keys:
        filters.append(getattr(AppointmentModel, "date") < func.DATE(args["end_date"]))
    if "date" in keys:
        filters.append(getattr(AppointmentModel, "date") == func.DATE(args["date"]))
    if "email" in keys:
        # If they want to search the email address of the clients too, then join the needed tables.
        query = query.join(ClientAppointmentModel).join(ClientModel)
        filters.append(getattr(ClientModel, "email").ilike("%" + args["email"] + "%"))
    if "appointment_includes" in keys:
        filters.append(or_(getattr(AppointmentModel, "description").contains(args["appointment_includes"]), getattr(AppointmentModel, "note").contains(args["appointment_includes"]), getattr(AppointmentModel, "feedback").contains(args["appointment_includes"])))
    else:
        if "description_includes" in keys and "note_includes" in keys:
            filters.append(or_(getattr(AppointmentModel, "description").ilike("%" + args["description_includes"] + "%"), getattr(AppointmentModel, "note").contains(args["note_includes"])))
        elif "description_includes" in keys and "feedback_includes" in keys:
            filters.append(or_(getattr(AppointmentModel, "description").ilike("%" + args["description_includes"] + "%"), getattr(AppointmentModel, "feedback").contains(args["feedback_includes"])))
        elif "note_includes" in keys and "feedback_includes" in keys:
            filters.append(or_(getattr(AppointmentModel, "note").ilike("%" + args["note_includes"] + "%"), getattr(AppointmentModel, "feedback").contains(args["feedback_includes"])))
        elif "description_includes" in keys:
            filters.append(getattr(AppointmentModel, "description").ilike("%" + args["description_includes"] + "%"))
        elif "note_includes" in keys:
            filters.append(getattr(AppointmentModel, "note").ilike("%" + args["note_includes"] + "%"))
        elif "feedback_includes" in keys:
            filters.append(getattr(AppointmentModel, "feedback").ilike("%" + args["feedback_includes"] + "%"))

    # Add the filters, if there are any
    if len(filters) > 0:
        query = query.filter(*filters)

    print(query)

    # Add pagination
    page = 1
    per_page = 20
    if "page" in args.keys():
        page = int(args["page"])
    if "per_page" in args.keys():
        per_page = int(args["per_page"])
    query = query.limit(per_page)
    query = query.offset((page-1)*per_page)

    appointments = query.all()

    # Query and return the results
    return appointments
