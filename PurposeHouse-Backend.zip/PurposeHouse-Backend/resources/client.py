from flask import request
from flask.views import MethodView
from flask_smorest import Blueprint, abort
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from sqlalchemy import or_

from flask_jwt_extended import jwt_required, get_jwt_identity
from permissions import protect

from db import db
from models import ClientModel, UserClientModel
from schemas import PlainClientSchema, ClientSchema, PlainAuthorizationSchema

blp = Blueprint("Clients", "clients", description="Operations on clients")

@blp.route("/client")
class ClientList(MethodView):
    @jwt_required()
    @blp.response(200, ClientSchema(many=True))
    def get(self):
        """Searches all clients. Admin Only.

        This route takes any of a pre-defined set of query parameters and filters queries based on them.
        Query parameters are currently fully listed and described in the Postman Documentation.
        """
        # Restrict to admin only, so they can search all clients
        protect(requestor_id=get_jwt_identity(), allowed_roles=["admin"])

        # This route includes pagination, which means that you can specify
        # the page and number of clients. 
        args = request.args
        return clientQuerier(args)
    
    @jwt_required(fresh=True)
    @blp.arguments(PlainClientSchema, description="Creates a client. Requires a fresh token.")
    @blp.response(201, PlainClientSchema, description="Client successfully created.")
    @blp.alt_response(422, description="Required fields for creating client not included.")
    @blp.alt_response(400, description="Duplicate email included.")
    @blp.alt_response(500, description="Server error in saving the client.")
    def post(self, client_data):
        """Create a client.
        
        Creates a client based on inputted information. Email must be unique."""
        #1) Create the client model
        client = ClientModel(**client_data)

        #2) Try to save the client model to the database.
        try:
            db.session.add(client)
            db.session.commit()
        except IntegrityError:
            abort(400, message="Email must be unique.")
        except SQLAlchemyError:
            abort(500, message="There was an error in saving the client to the database.")

        return client, 201

@blp.route("/client/<int:client_id>")
class Client(MethodView):
    @jwt_required()
    @blp.response(200, ClientSchema)
    @blp.alt_response(404, description="Client not found.")
    def get(self, client_id):
        """Get client information by ID.
        
        This route gets client information by the client_id.
        """
        client = ClientModel.query.get_or_404(client_id)
        return client

    # This route updates clients, but also will create a client
    # if one with that ID doesn't exist.
    @jwt_required(fresh=True)
    @blp.arguments(PlainClientSchema)
    @blp.response(200, PlainClientSchema, description="Client successfully updated.")
    @blp.alt_response(201, description="Client successfully created.")
    @blp.alt_response(422, description="Required fields for creating client not included.")
    @blp.alt_response(400, description="Duplicate email included.")
    @blp.alt_response(500, description="Server error in saving the client.")
    def put(self, client_data, client_id):
        """Update or create a client

        This route technically updates a client, but if no client with that specific id exists, it will
        create the client. 
        """
        client = ClientModel.query.get(client_id)
        if client:
            client.first_name = client_data["first_name"]
            client.last_name = client_data["last_name"]
            client.title = client_data["title"]
            client.email = client_data["email"]
        else:
            client = ClientModel(id=client_id, **client_data)

        # Try to update / create the client.
        try:
            db.session.add(client)
            db.session.commit()
        except IntegrityError:
            abort(400, message="Email must be unique.")
        except SQLAlchemyError:
            abort(500, message="There was an error in saving or updating the client to the database.")

        return client

    # Deletes a client from the database.
    # Only admins can access this route.
    @jwt_required(fresh=True)
    @blp.response(200, description="Client deleted successfully.")
    @blp.alt_response(404, description="Client not found.")
    def delete(self, client_id):
        """Delete a Client (admin only)
        
        Deletes a client from the database."""
        #1) Abort the request if the user does not exist and restrict to admin
        protect(requestor_id=get_jwt_identity(), allowed_roles=["admin"])

        #2) Get the client from the database.
        client = ClientModel.query.get_or_404(client_id)

        #3) Delete the client from the database.
        db.session.delete(client)
        db.session.commit()
        return {"message": "Client deleted."}, 200

def clientQuerier(args):
    filters = []

    # Construct the query
    query = db.session.query(ClientModel)

    keys = args.keys()
    if "councilor_id" in keys:
        # Add the additional table to search for the councilors if we're doing that.
        query = query.join(UserClientModel)
        filters.append(getattr(UserClientModel, "user_id") == args["councilor_id"])
    if "email" in keys:
        filters.append(getattr(ClientModel, "email") == args["email"])
    if "name" in keys:
        filters.append(or_(getattr(ClientModel, "first_name").ilike("%" + args["name"] + "%"), getattr(ClientModel, "last_name").ilike("%" + args["name"] + "%")))
    elif "first_name" in keys:
        filters.append(getattr(ClientModel, "first_name").ilike("%" + args["first_name"] + "%"))
    elif "last_name" in keys:
        filters.append(getattr(ClientModel, "last_name").ilike("%" + args["last_name"] + "%"))

    # Add the filters, if there are any
    if len(filters) > 0:
        query = query.filter(*filters)

    print(query)

    # Add pagination
    page = 1
    per_page = 20
    if "page" in args.keys():
        page = int(args["page"])
    if "per_page" in args.keys():
        per_page = int(args["per_page"])
    query = query.limit(per_page)
    query = query.offset((page-1)*per_page)

    appointments = query.all()

    # Query and return the results
    return appointments