import React, { useState, useEffect} from 'react';
import axios from 'axios'
import bc from '../layout/Images/i1.png';
import { Link } from 'react-router-dom';
import FollowupDashboard from '../followup_ui/followupDashboard';
import TextField from '@mui/material/TextField';
import Checkbox from '@mui/material/Checkbox';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import "./Home.css";
import "./Followup.css";

const Followup = () =>  {

    const [ searchText, setSearchText ] = useState("");
    const [ searchedResult, setSearchedResult ] = useState([]);

    const [ isAdvanceFilterClicked, setIsAdvancedFilterClicked ] = useState(false);

    let access_token = sessionStorage.getItem('access_token');

    let delay;

    const fetchFollowups = async()=> {
        console.log('call Api',searchText)
        let isAnyOfEmailFirstNameOrLastNameEmpty = true
        let params = {}
        // if(emailFilterStatus){
        //     params['email'] = searchText;
        //     isAnyOfEmailFirstNameOrLastNameEmpty = false
        // }
        // if(startDate){
        //   params['start_date'] = searchText;
        //   isAnyOfEmailFirstNameOrLastNameEmpty = false
        // }
        // if(endDate){
        //   params['end_date'] = searchText;
        //   isAnyOfEmailFirstNameOrLastNameEmpty = false
        // }
        // if(date){
        //   params['date'] = searchText;
        //   isAnyOfEmailFirstNameOrLastNameEmpty = false
        // }
  
        // if(isAnyOfEmailFirstNameOrLastNameEmpty){
        //   params['appointment_includes'] = searchText;
        // }
  
        await axios.get("/followup",{ params: params,headers: {"Authorization" : `Bearer ${access_token}`} })
          .then(res => {
              if(res.status === 201){
                  console.log("res",res)
                  setSearchedResult(res.data)
              }
          })
          .catch(err => console.log("error in fetching clients"))
      }
  
        useEffect(() => {
          fetchFollowups()
        },[])
      
        useEffect(() => {
          if(searchText){
              delay = setTimeout(() => {
                  if(searchText)fetchFollowups()
                }, 1000)
            
                return () => clearTimeout(delay)
          }
          else{
              fetchFollowups()
          }
           
        }, [searchText])
      
        const keyDown = (e)=>{
          if (e.key === "Enter") {
            clearTimeout(delay)
            fetchFollowups()
            console.log('keyDown press and ready for api call')
          }
        }

        return (
            <>
                 <Box>
                    <Box
                        sx={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        p: 1,
                        m: 1,
                        mt: 20,
                        bgcolor: 'background.paper',
                        borderRadius: 1,
                        }}
                    >
                        <div>
                            <p className='counciler-counciler'>Counciler:</p>
                            <div className='counclier-static-left'>
                                <img src="/download-icon.svg" height={20} width={20} className="counciler-static-arror-icon" />
                                <button className='counciler-static-btn'>YOU</button>
                            </div>
                        </div>
                        
                        <Box sx={{width: '75ch',     marginTop: "35px"}}>
                            <TextField id="outlined-basic" 
                                    label="Search" 
                                    variant="outlined"
                                    placeholder='Search Name, Email, First Name, Last Name'
                                    value={searchText} 
                                    onChange={(e) => setSearchText(e.target.value)}
                                    onKeyDown={keyDown} className="search-bar-input"
                                    sx={{width: 500}}
                                   
                                        />
                            <p onClick={() => setIsAdvancedFilterClicked(!isAdvanceFilterClicked)}
                            className={isAdvanceFilterClicked ? "advance-filter-active" : "advance-filter"}
                            >
                                Advance Filters
                            </p>
                            
                            {/* {isAdvanceFilterClicked && (
                                <div className='advance-filer-main'>
                                    
                                    <Checkbox type="checkbox" 
                                        id="email" 
                                        name="email"
                                        onChange={(e) => setEmailFilterStatus(e.target.checked) }
                                        checked={emailFilterStatus}
                                        color="default"
                                        />
                                    <label htmlFor="email" className='filter-menu-input-label'> Email</label>

                                    <Checkbox type="checkbox" 
                                         id="date" 
                                         name="date" 
                                         value={date}
                                         onChange={(e) =>  setDate(e.target.checked)}
                                         />
                                    <label htmlFor="date" className='filter-menu-input-label'> Date</label>

                                    <Checkbox type="checkbox" 
                                         id="description" 
                                         name="description" 
                                         value={description}
                                         onChange={(e) =>  setDescription(e.target.checked)}
                                         />
                                    <label htmlFor="description" className='filter-menu-input-label'> Description</label>
                                </div>
                            )} */}
                        
                        </Box>
                        
                        <div style={{margin: "30px"}}>
                                <Button variant="contained"
                                        component={Link} 
                                        to="/followupCreate">+create</Button>
                        </div>

                    </Box>

                    
                    <FollowupDashboard searchedResult={searchedResult} 
                                     accessToken={access_token} 
                                     fetchFollowups={fetchFollowups} 
                                     />
            </Box>
            </>
            // <div className="container">
             
            //     <div className="search">
            //     <input type="text" placeholder='  search followup...'/>
            //     </div>
            //     <div>
                
            //     <FollowupDashboard />
            //     </div>
            // </div>
        )
}

export default Followup;