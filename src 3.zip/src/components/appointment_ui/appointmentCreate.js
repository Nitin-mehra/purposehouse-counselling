import React, { Component, useState} from "react";
import { Link } from "react-router-dom";
import axios from 'axios';
import { useNavigate, useLocation } from "react-router-dom";

import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
// import Link from '@mui/material/Link';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';

const theme = createTheme();

const Appointment = ()=>{
    const navigate = useNavigate();
    const location = useLocation();

    let appoinmentDetails = location.state
    console.log("appoinmenrt props",location.state)

    const [ date, setDate ] = useState("")
    const [ description, setDescription ] = useState("")
    const [ note, setNote ] = useState("")
    const [ feedback, setFeedback ] = useState("")

    let access_token = sessionStorage.getItem('access_token');
    let refresh_token = sessionStorage.getItem('refresh_token');
    let client_id = sessionStorage.getItem('client_id');
    let councilor_id = sessionStorage.getItem('councilor_id');

    const onSubmit = e => {
        e.preventDefault();
    
    
    const newAppointment = {
          date: date,
          description: description,
          note: note,
          feedback: feedback,
          counselor_id: councilor_id
        };
        axios.post('/appointment',newAppointment,{ headers: {"Authorization" : `Bearer ${access_token}`} })
        .then((res) => {
          if (res.status === 201) {
            console.log(res.status)

            let appointment_id = res.data.id
            console.log(appointment_id)

            const params = {
              appointment_id: parseInt(appointment_id),
              client_id: parseInt(client_id)
            };

            axios.post(`/appointment/${appointment_id}/client/${client_id}`,{params},{ headers: {"Authorization" : `Bearer ${access_token}`} })
            .then((res) =>{
              if (res.status === 201){
                console.log("appointment create",res.status)
                console.log("Appointment link to client")
                navigate("/appointments");
                
              }
            })
            .catch((e)=> {console.log('unable to link appointment to client')})
          }
        })
        .catch((e)=> {console.log('unable to add data from axios')})
    
        console.log(newAppointment);
      };

      
    return(

      <>
      
      <Box
                   sx={{
                   p: 1,
                   m: 1,
                   mt: 15,
                   mb:0,
                   bgcolor: 'background.paper',
                   borderRadius: 1,
                   }}
               >
                <Button variant="default" component={Link} to="/appointments">
                   <i className="material-icons left">keyboard_backspace</i>
                   Back to home
                 </Button> 
       </Box>
       <ThemeProvider theme={theme}>
         <Container component="main" maxWidth="xs">
           <CssBaseline />
           <Box
             sx={{
               display: 'flex',
               flexDirection: 'column',
               alignItems: 'center',
             }}
           >
             <Typography component="h1" variant="h5">
               Create Appoinment
             </Typography>
             <Box component="form" onSubmit={onSubmit} noValidate sx={{ mt: 1 }}>
              
               <TextField
                 margin="normal"
                 required
                 label="Date"
                //  name="date"
                //  autoComplete="date"
                 autoFocus
                 onChange={(e)=> setDate(e.target.value)}
                  value={date}
                //   error={errors.date}
                  id="date"
                  type="date"
               />
               <TextField
                 margin="normal"
                 required
                 fullWidth
                 name="description"
                 label="Description"
                 id="description"
                 autoComplete="description"
                 onChange={(e)=> setDescription(e.target.value)}
                 value={description}
               />

             <TextField
                 margin="normal"
                 required
                 fullWidth
                 name="note"
                 label="Note"
                 id="note"
                 autoComplete="note"
                 onChange={(e)=> setNote(e.target.value)}
                 value={note}
               />

             <TextField
                 margin="normal"
                 required
                 fullWidth
                 name="feedback"
                 label="Feedback"
                 id="feedback"
                 autoComplete="feedback"
                 onChange={(e)=> setFeedback(e.target.value)}
                 value={feedback}
               />
         
               <Button
                 type="submit"
                 fullWidth
                 variant="contained"
                 sx={{ mt: 3, mb: 2 }}
               >
                 {appoinmentDetails ? "Update" : "Create"}
              
               </Button>
              
             </Box>
           </Box>
         </Container>
       </ThemeProvider>
       </>
      //   <div className="container">
      //   <div className="row">
      //     <div className="col s8 offset-s2">
      //       <Link to="/" className="btn-flat waves-effect">
      //         <i className="material-icons left">keyboard_backspace</i> Back to
      //         home
      //       </Link>
      //       <form noValidate onSubmit={onSubmit}>
      //         <div className="input-field col s12">
      //           <input
      //             onChange={(e)=> setDate(e.target.value)}
      //             value={date}
      //           //   error={errors.date}
      //             id="date"
      //             type="date"
      //           />
      //           <label htmlFor="date">Date</label>
      //         </div>
      //         <div className="input-field col s12">
      //           <input
      //             onChange={(e)=> setDescription(e.target.value)}
      //             value={description}
      //           //   error={errors.description}
      //             id="description"
      //             type="text"
      //           />
      //           <label htmlFor="description">Description</label>
      //         </div>
      //         <div className="input-field col s12">
      //           <input
      //             onChange={(e)=> setNote(e.target.value)}
      //             value={note}
      //           //   error={errors.note}
      //             id="note"
      //             type="text"
      //           />
      //           <label htmlFor="note">Note</label>
      //         </div>
      //         <div className="input-field col s12">
      //           <input
      //             onChange={(e)=> setNote(e.target.value)}
      //             value={feedback}
      //           //   error={errors.feedback}
      //             id="feedback"
      //             type="text"
      //           />
      //           <label htmlFor="feedback">Feedback</label>
      //         </div>
      //         <div className="col s12" style={{ paddingLeft: "11.250px" }}>
      //           <button
      //             style={{
      //               width: "200px",
      //               borderRadius: "3px",
      //               letterSpacing: "1.5px",
      //               marginTop: "1rem"
      //             }}
      //             type="submit"
      //             className="btn btn-large waves-effect waves-light hoverable blue accent-3"
      //           >
      //            +Appointment
      //           </button>
      //         </div>
      //       </form>

      //     </div>
      //   </div>
      // </div>   
    )
}

export default Appointment;