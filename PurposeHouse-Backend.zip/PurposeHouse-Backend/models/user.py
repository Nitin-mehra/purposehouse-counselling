from db import db

import enum
from sqlalchemy import Enum

# This class takes care of storing the users.
# The users include 'type', which indicates whether the
# user is a councillor or an admin.

class user_type(enum.Enum):
    admin = "admin",
    councilor = "councilor"

class UserModel(db.Model):
    __tablename__ = 'user'

    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(80), unique=False, nullable=False)
    last_name = db.Column(db.String(80), unique=False, nullable=False)
    title = db.Column(db.String(10), unique=False, nullable=False)
    role = db.Column(db.String(15), unique=False, nullable=False)

    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(), unique=False, nullable=False)

    appointments = db.relationship("AppointmentModel", back_populates="councilor", lazy="dynamic")
    clients = db.relationship("ClientModel", back_populates="councilors", secondary="user_client", lazy="dynamic")
    follow_ups = db.relationship("FollowUpModel", back_populates="councilor", lazy="dynamic")