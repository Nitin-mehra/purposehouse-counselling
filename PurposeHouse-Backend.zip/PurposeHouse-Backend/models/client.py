from db import db

# This class takes care of storing the clients.

class ClientModel(db.Model):
    __tablename__ = 'client'

    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(80), unique=False, nullable=False)
    last_name = db.Column(db.String(80), unique=False, nullable=False)
    title = db.Column(db.String(10), unique=False, nullable=False)
    email = db.Column(db.String(80), unique=True, nullable=False)

    appointments = db.relationship("AppointmentModel", back_populates="clients", secondary="client_appointment", lazy="noload")
    councilors = db.relationship("UserModel", back_populates="clients", secondary="user_client", lazy="dynamic")
    follow_ups = db.relationship("FollowUpModel", back_populates="clients", secondary="client_follow_up", lazy="dynamic")