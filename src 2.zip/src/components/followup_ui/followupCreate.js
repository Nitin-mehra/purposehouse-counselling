import React, { Component, useState} from "react";
import { Link } from "react-router-dom";
import axios from 'axios';
import { useNavigate, useLocation } from "react-router-dom";

import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';

const theme = createTheme();


const Followup = ()=>{

  const navigate = useNavigate();
  const location = useLocation();


  let clientDetails = location.state
  console.log("createprops",location.state)

    const [ title, setTitle ] = useState("")
    const [ body, setBody ] = useState("")

    let access_token = sessionStorage.getItem('access_token');
    let refresh_token = sessionStorage.getItem('refresh_token');
    let councilor_id = sessionStorage.getItem('councilor_id');
    let client_id = sessionStorage.getItem('client_id');

    // const onSubmit = e => {
    //     e.preventDefault();
    
    
    // const newFollowup = {
    //       title: title,
    //       body: body,
    //       councilor_id: councilor_id
    //     };
    //     axios.post('/followup',newFollowup,{ headers: {"Authorization" : `Bearer ${access_token}`} })
    //     .then((res) => {
    //       // if Registration is successful then open the home page directly
    //       if (res.status === 201) {
    //         console.log(res)
    //         console.log("Followup Created!")
    //         let followup_id = res.data.id
    //         console.log(followup_id)

    //         const params = {
    //           followup_id: followup_id,
    //           client_id: client_id
    //         };

    //         axios.post(`/followup/${followup_id}/client/${client_id}`,{params},{ headers: {"Authorization" : `Bearer ${access_token}`} })
    //         .then((res) =>{
    //           if (res.status === 200){
    //             console.log("Followup linked to client")
    //             navigate("/appointments");
                
    //           }
    //         })
    //         .catch((e)=> {console.log('unable to link appointment to client')})
            
    //       }
    //     })
    //     .catch((e)=> {console.log('unable to add data from axios')})
    
    //     console.log(newFollowup);
    
    //   };

    const onSubmit = e => {
      e.preventDefault();
  
  
  const newFollowup = {
        title: title,
        body: body,
        counselor_id: parseInt(councilor_id)
      };
      axios.post('/followup',newFollowup,{ headers: {"Authorization" : `Bearer ${access_token}`} })
      .then((res) => {
        // if Registration is successful then open the home page directly
        if (res.status === 201) {
          console.log(res)
          console.log("Followup Created!")
          let followup_id = res.data.id
          console.log(followup_id)

          const params = {
            followup_id: followup_id,
            client_id: client_id
          };

          axios.post(`/followup/${followup_id}/client/${client_id}`,{params},{ headers: {"Authorization" : `Bearer ${access_token}`} })
          .then((res) =>{
            if (res.status === 200){
              console.log("Followup linked to client")
              navigate("/appointments");
              
            }
          })
          .catch((e)=> {console.log('unable to link appointment to client')})
          
        }
      })
      .catch((e)=> {console.log('unable to add data from axios')})
  
      console.log(newFollowup);
  
    };

      
    return(
      <>
      <Box
                   sx={{
                   p: 1,
                   m: 1,
                   mt: 15,
                   mb:0,
                   bgcolor: 'background.paper',
                   borderRadius: 1,
                   }}
               >
                <Button variant="default" component={Link} to="/followup">
                   <i className="material-icons left">keyboard_backspace</i>
                   Back to home
                 </Button> 
       </Box>
       <ThemeProvider theme={theme}>
         <Container component="main" maxWidth="xs">
           <CssBaseline />
           <Box
             sx={{
               display: 'flex',
               flexDirection: 'column',
               alignItems: 'center',
             }}
           >
             <Typography component="h1" variant="h5">
               Create Followup
             </Typography>
             <Box component="form" onSubmit={onSubmit} noValidate sx={{ mt: 1 }}>
               <TextField
                 margin="normal"
                 required
                 fullWidth
                 id="title"
                 label="Title"
                 name="title"
                 autoComplete="title"
                 autoFocus
                 onChange={(e)=> setTitle(e.target.value)}
                 value={title}
               />
               <TextField
                 margin="normal"
                 required
                 fullWidth
                 name="body"
                 label="Body"
                 type="body"
                 id="body"
                 autoComplete="body"
                 onChange={(e)=> setBody(e.target.value)}
                 value={body}
               />

           
          
         
               <Button
                 type="submit"
                 fullWidth
                 variant="contained"
                 sx={{ mt: 3, mb: 2 }}
               >
                 {clientDetails ? "Update" : "Create"}
              
               </Button>
              
             </Box>
           </Box>
         </Container>
       </ThemeProvider>
      </>
      //   <div className="container">
      //   <div className="row">
      //     <div className="col s8 offset-s2">
      //       <Link to="/" className="btn-flat waves-effect">
      //         <i className="material-icons left">keyboard_backspace</i> Back to
      //         home
      //       </Link>
      //       <form noValidate onSubmit={onSubmit}>
      //         <div className="input-field col s12">
      //           <input
      //             onChange={(e)=> setTitle(e.target.value)}
      //             value={title}
      //           //   error={errors.date}
      //             id="date"
      //             type="date"
      //           />
      //           <label htmlFor="date">Title</label>
      //         </div>
      //         <div className="input-field col s12">
      //           <input
      //             onChange={(e)=> setBody(e.target.value)}
      //             value={body}
      //           //   error={errors.description}
      //             id="description"
      //             type="text"
      //           />
      //           <label htmlFor="description">Body</label>
      //         </div>
      //         <div className="col s12" style={{ paddingLeft: "11.250px" }}>
      //           <button
      //             style={{
      //               width: "200px",
      //               borderRadius: "3px",
      //               letterSpacing: "1.5px",
      //               marginTop: "1rem"
      //             }}
      //             type="submit"
      //             className="btn btn-large waves-effect waves-light hoverable blue accent-3"
      //           >
      //            +Followup
      //           </button>
      //         </div>
      //       </form>

      //     </div>
      //   </div>
      // </div>   
    )
}

export default Followup;