from flask import request
from flask.views import MethodView
from flask_smorest import Blueprint, abort
from sqlalchemy.exc import SQLAlchemyError, IntegrityError

from flask_jwt_extended import jwt_required, get_jwt_identity
from permissions import protect
import datetime

from db import db
from sqlalchemy import or_, func
from models import FollowUpModel, ClientModel, ClientFollowUpModel
from schemas import FollowUpSchema, PlainFollowUpSchema, PlainAuthorizationSchema

blp = Blueprint("Follow-Up", "follow-up", description="Operations on follow-ups")

@blp.route("/followup")
class FollowUpList(MethodView):
    @jwt_required()
    @blp.response(200, FollowUpSchema(many=True))
    def get(self):
        """Searches all follow-ups. Admin Only.

        This route takes any of a pre-defined set of query parameters and filters queries based on them.
        Query parameters are currently fully listed and described in the Postman Documentation.
        """
        # Restrict this role to admins only. 
        protect(requestor_id=get_jwt_identity(), allowed_roles=["admin"])

        # This route includes pagination, which means that you can specify
        # the page and number of clients.
        return followUpQuerier(request.args)

    @jwt_required()
    @blp.arguments(PlainFollowUpSchema, location="form", description="Creates a follow-up")
    @blp.response(201, PlainFollowUpSchema, description="Follow-up successfully created.")
    @blp.alt_response(422, description="Required fields for creating follow-up not included.")
    @blp.alt_response(500, description="Server error in saving the follow-up.")
    def post(self, follow_up_data):
        """Creates a follow-up
        
        Creates a follow-up which is automatically associated with the user."""
        
        #1) Set the councilor ID based on whether it was passed or not.
        if "councilor_id" in follow_up_data:
            councilor_id = follow_up_data["councilor_id"]
        else:
            councilor_id = get_jwt_identity()

        #2) Create the followUpModel
        follow_up = FollowUpModel (
            title = follow_up_data["title"],
            body = follow_up_data["body"],
            date = datetime.date.today(),

            councilor_id = councilor_id
        )

        #3) Try to save the follow-up model to the database. 
        try:
            db.session.add(follow_up)
            db.session.commit()
        except SQLAlchemyError:
            abort(500, message="There was an error in saving the follow-up to the database.")

        return follow_up, 201

@blp.route("/followup/<int:follow_up_id>")
class FollowUp(MethodView):
    @jwt_required()
    @blp.response(200, FollowUpSchema, description="Returns the follow-up associated with this ID.")
    @blp.alt_response(404, description="The follow-up was not found.")
    def get(self, follow_up_id):
        """Get follow-up information by ID.
        
        This route gets the follow-up information by the follow_up_id.
        """
        # RESTRICT COUNCILORS TO ONLY GET FOLLOWUPS FROM THEIR OWN CLIENTS

        follow_up = FollowUpModel.query.get_or_404(follow_up_id)
        return follow_up

    @jwt_required(fresh=True)
    @blp.response(200, description="Returns that the follow-up was successfully deleted.")
    @blp.alt_response(404, description="The follow-up was not found.")
    @blp.alt_response(500, description="Server error in deleting the follow-up.")
    def delete(self, follow_up_id):
        # RESTRICT COUNCILORS TO ONLY GET FOLLOWUPS FROM THEIR OWN CLIENTS

        user = protect(requestor_id=get_jwt_identity(), allowed_roles=["admin", "councilor"])

        #2) Get the follow-up from the database
        follow_up = FollowUpModel.query.get_or_404(follow_up_id)

        #3) Delete the follow-up from the database.
        try:
            db.session.delete(follow_up)
            db.session.commit()
        except SQLAlchemyError:
            abort(500, message="There was an error deleting the follow-up from the database.")
        return { "message": "Follow-up deleted."}, 200

@blp.route("/followup/<int:follow_up_id>/client/<int:client_id>")
class LinkClientToFollowUp(MethodView):
    @jwt_required(fresh=True)
    @blp.response(201, description="Client linked to follow-up successfully.")
    @blp.alt_response(404, description="Follow-up or client not found.")
    @blp.alt_response(400, description="The follow-up is already linked to the client.")
    @blp.alt_response(500, description="An error occurred in saving the link to the database.")
    def post (self, follow_up_id, client_id): 
        """Link Follow-up to Client
        
        This route links a specific follow-up to a specific client. This allows for two things. First, 
        once they are linked, the information will be sent to this client. Secondly, users will be able
        to filter follow-ups by specific clients."""
        follow_up = FollowUpModel.query.get_or_404(follow_up_id)
        client = ClientModel.query.get_or_404(client_id)

        follow_up.clients.append(client)
        try:
            db.session.add(follow_up)
            db.session.commit()
        except IntegrityError:
            abort(400, message="Client is already linked to this follow-up.")
        except SQLAlchemyError:
            abort(500, message="There was an error in linking this client to this follow-up.")

        return {"message": "Follow-up {} linked to client {}.".format(follow_up_id, client_id)}, 200
    

    @jwt_required(fresh=True)
    @blp.response(200, description="Client unassociated successfully.")
    @blp.alt_response(404, description="Follow-up, client, or follow-up-client link was not found.")
    @blp.alt_response(500, description="An error occurred in deleting the link from the database.")
    def delete(self, follow_up_id, client_id):
        """Delete a follow-up from the database."""
        # This line verifies that the appointment and client are actually linked.
        follow_up_client = ClientFollowUpModel.query.get_or_404([client_id, follow_up_id])

        follow_up = FollowUpModel.query.get_or_404(follow_up_id)
        client = ClientModel.query.get_or_404(client_id)

        follow_up.clients.remove(client)
        try:
            db.session.add(client)
            db.session.commit()
        except SQLAlchemyError:
            abort(500, message="There was an error in unlinking this client from the follow-up.")

        return {"message": "Follow-up {} unlinked from client {}.".format(follow_up_id, client_id)}, 200

# This is a large filter for the follow-ups which essentially filters on all the attributes.
def followUpQuerier(args):
    filters = []

    # Create the query
    query = db.session.query(FollowUpModel)

    keys = args.keys()
    if "councilor_id" in keys:
        filters.append(getattr(FollowUpModel, "councilor_id") == args["councilor_id"])
    if "start_date" in keys:
        filters.append(getattr(FollowUpModel, "date") >= func.DATE(args["start_date"]))
    if "end_date" in keys:
        filters.append(getattr(FollowUpModel, "date") < func.DATE(args["end_date"]))
    if "date" in keys:
        filters.append(getattr(FollowUpModel, "date") == func.DATE(args["date"]))
    if "email" in keys:
        # If they want to search the email address of the clients too, then join the needed tables.
        query = query.join(ClientFollowUpModel).join(ClientModel)
        filters.append(getattr(ClientModel, "email").ilike("%" + args["email"] + "%"))
    if "follow_up_includes" in keys:
        filters.append(or_(getattr(FollowUpModel, "title").contains(args["follow_up_includes"]), getattr(FollowUpModel, "body").contains(args["follow_up_includes"])))
    else:
        if "title_includes" in keys:
            filters.append(getattr(FollowUpModel, "title").ilike("%" + args["title_includes"] + "%"))
        elif "body_includes" in keys:
            filters.append(getattr(FollowUpModel, "body").ilike("%" + args["body_includes"] + "%"))

    # Add the filters, if there are any
    if len(filters) > 0:
        query = query.filter(*filters)

    print(query)

    # Add pagination
    page = 1
    per_page = 20
    if "page" in args.keys():
        page = int(args["page"])
    if "per_page" in args.keys():
        per_page = int(args["per_page"])
    query = query.limit(per_page)
    query = query.offset((page-1)*per_page)

    follow_ups = query.all()

    # Query and return the results
    return follow_ups