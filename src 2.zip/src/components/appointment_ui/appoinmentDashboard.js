import React from 'react';
import '../style/clientDashboard.css';
import { Card, Snackbar } from '@mui/material';
import axios from 'axios';
import { useNavigate, useLocation } from "react-router-dom";

const AppoinmentDashboard = (props) => {
    const navigate = useNavigate();
    const handleDelete = async (e,appoinemntId) => {
        e.preventDefault();

        await axios.delete(`/appointment/${appoinemntId}`, {headers: {"Authorization" : `Bearer ${props.accessToken}`}})
            .then(res => {
                if(res.status === 200){
                    console.log("clientdelteres",res)
                    props.fetchAppoinments()
                }
            })
            .catch(err => console.log("error in deleting appointment"))
    }

    return(
        <>

            {props.searchedResult.map(appoinemnt => {
                            console.log("check",appoinemnt)
                            return(

                                <Card variant="outlined" className='main-card' sx={{background: "#F3EFE0"}} >
                                <div>
                                    <h1> {appoinemnt.description}</h1>
                                </div>
        
                                <div className='client-dashboard-buttons'>
                                    
                                        <button className='client-btn' onClick={(e) => navigate("/followupCreate")}>
                                            
                                            Create Feedback
                                        </button>
        
                                    <button className='client-btn' 
                                    onClick={(e) => handleDelete(e,appoinemnt.id)}
                                    >
                                        Delete
                                    </button>
                                </div>
                            </Card>

                        //         <div className='main-card'>
                        //     <div>
                        //         <h1> {appoinemnt.description}</h1>
                        //     </div>

                        //     <div className='client-dashboard-buttons'>
                        //             <button className='client-btn'>
                        //                 Create Feedback
                        //             </button>
                        //     </div>
                        // </div>
                            )
                        })}
        </>
    )
}

export default AppoinmentDashboard;