from models.user import UserModel
from models.client import ClientModel
from models.appointment import AppointmentModel
from models.user_client import UserClientModel
from models.follow_up import FollowUpModel
from models.client_appointment import ClientAppointmentModel
from models.client_follow_up import ClientFollowUpModel