This is the backend for PurposeHouse application.

## SETUP DATABASE

1. Download and install PostgreSQL from https://www.postgresql.org/download/. Make sure the box to install PGAdmin is ticked. Leave the defaults. No need to launch stack builder at the end. Note the password that you created.

2. Open pgAdmin4 and login. If the login doesn't work, click the button to reset the password. I would set it to the same one as the Superuser password, for ease.

3. Right click 'databases,' and then click 'create.' If you change the default user, note the name. Name the database what you want, and note the database name.

4. Almost done! We just have to copy the database variables into the .env file so that our application can connect to the database.

The database URL (DATABASE_URL=pg://postgres:Pass1234@localhost:5432/blog) contains the database owner username, database owner password, and database name. They're positioned like so:

`DATABASE_URL=pg://database_owner_name:database_owner_password@localhost:5432/database_name`

Copy your own values into those slots.

## SETUP APP

1. This is a python 3 app. So, ensure that you have python 3 installed.

2. GIT clone this application into your code editor of choice.

3. Open a new terminal (preferrably within your code editor) and ensure that it is navigated to the directory of this repo

4. Type 'python -m venv .venv' to create a new virtual environment.

5. Close and restart the terminal, ensuring that it's still navigated to the directory of this repo.

6. Install the required packages by typing 'pip install -r requirements.txt'

9. In your .env file, paste JWT_ACCESS_TOKEN_EXPIRES=12, where the number is the number of hours you want the token valid for.

8. To start the application, type 'flask run'

9. You can then send requests to the application with the URL 'http://localhost:5000'. You can also view documentation for this (including available routes) by going to the browser and typing http://localhost:5000/api-docs
