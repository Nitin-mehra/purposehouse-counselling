import React, { Component, useEffect, useState } from 'react';
import "./CardData.css";

import axios from 'axios';

const CardData = () =>  {

    const [ clientsList, setClientList ] = useState([])
    const [ appoinmentList, setAppoinmentList ] = useState([])

    let access_token = sessionStorage.getItem('access_token');

        useEffect(() => {
            axios.get(`/client`,{ headers: {"Authorization" : `Bearer ${access_token}`} })
            .then((res) => {
                // if Registration is successful then open the home page directly
                if (res.status === 200) {
                  console.log(res,"client get success")
                  setClientList(res.data)
                  
                }
              })
              .catch((e)=> {
                console.log('cannot get clients')
                setClientList([])
            })

            axios.get('/appointment',{ headers: {"Authorization" : `Bearer ${access_token}`} })
            .then((res) => {
                if (res.status === 200) {
                    console.log(res,"appoinment get success")
                    setAppoinmentList(res.data)
                  }
            })
            .catch((e)=> {
                console.log('cannot get appoinemnts')
                setAppoinmentList([])
            })
              
        },[])
        // const clients = ClientName.map(client => {
        //     return (
        //         <h6 className="client_name">{client.name}</h6>
        //     );
        // })

        // const appointmentData = appointment.map(data => {
        //     return (
        //         <div className="client_data">
        //             <p className="name">{data.name}</p>
        //             <div>
        //                 <p className="day">{data.day},</p>
        //                 <p className="date">{data.date}</p>
        //             </div>
        //             <p className="time">{data.time}</p>
        //         </div>
        //     );
        // })
        return (
            <>
            <div className="wrapper">
                <div className="client_name">
                    <h5>Clients you usually interact with on Wednesdays...</h5>

                    <div class="row">
                        {clientsList.map(client => (
                            <div class="column">
                                <div class="card">{`${client.first_name} ${client.last_name}`} </div>
                            </div>
                        ))}
                    </div>
                  
                    {/* <div className="footer_section">See more...</div> */}
                </div>

                <div className="client_details">
                    <h5>Appointments you had 3-5 days ago...</h5>
                    <div class="row">
                        {appoinmentList.map(appoinment => (
                             <div class="column">
                            <div className="appoinment-card">
                                <h2>{appoinment.description}</h2>
                                <h6>{appoinment.date}</h6>
                            </div>
                            </div>
                        ))}
                    </div>
                    {/* <div className='client-cards-main'>
                    {appoinmentList.map(appoinment => (
                        <div className="appoinment-card">
                            <h2>{appoinment.description}</h2>
                            <h6>{appoinment.date}</h6>
                        </div>
                    ))}
                    </div> */}
                    {/* <div className="footer_section">See more...</div> */}
                </div>

            </div>

            </>
        );
    
}

export default CardData;