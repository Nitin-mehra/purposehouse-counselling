import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import axios from 'axios';

import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
// import Link from '@mui/material/Link';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Domain from "../utils/domain";

const theme = createTheme();

const  Register = () =>  {
  const navigate = useNavigate();
  const domainName = Domain()

  const [ firstName, setFirstName] = useState('');
  const [ lastName, setLastName] = useState('');
  const [ title, setTitle] = useState('');
  const [ email, setEmail] = useState('');
  const [ password, setPassword] = useState('');

  const userInfo = sessionStorage.getItem('access_token');
  useEffect(() => {
      //This is force redirect
      if(userInfo){
          navigate('/home');
      }else{
          navigate('/register')
      }
  }, [userInfo, navigate])

const onChange = e => {
    this.setState({ [e.target.id]: e.target.value });
  };

const  onSubmit = e => {
    e.preventDefault();

const newUser = {
      first_name: firstName,
      last_name: lastName,
      title: title,
      email: email,
      password: password
    };

    axios.post(`/register`,newUser)
    .then((res) => {
      console.log(res.data)
      // if Registration is successful then open the home page directly
      if (res.status === 201) {
        console.log(res)
        sessionStorage.setItem("access_token", res.data.access_token)
        sessionStorage.setItem("refresh_token", res.data.refresh_token)
        sessionStorage.setItem("councilor_id", res.data.id)

        // window.open('/home', "_self")
      }
    })
    .catch((e)=> {console.log('unable to add data from axios')})

    console.log(newUser);

  };

return (
  <>
     <ThemeProvider theme={theme}>
                <Container component="main" maxWidth="xs">
                <CssBaseline />
                <Box
                    sx={{
                    marginTop: 20,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    }}
                >
                    <Avatar sx={{ m: 1, bgcolor: 'secondary.main' }}>
                    <LockOutlinedIcon />
                    </Avatar>
                    <Typography component="h1" variant="h5">
                    Register
                    </Typography>
                    <Box component="form" onSubmit={onSubmit} noValidate sx={{ mt: 1 }}>
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        id="firstName"
                        label="First Name"
                        name="firstName"
                        autoComplete="firstName"
                        autoFocus
                        onChange={(e) => setFirstName(e.target.value)}
                        value={firstName}
                    />
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        id="lastName"
                        label="Last Name"
                        name="lastName"
                        autoComplete="lastName"
                        autoFocus
                        onChange={(e) => setLastName(e.target.value)}
                        value={lastName}
                    />
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        id="title"
                        label="Title"
                        name="title"
                        autoComplete="title"
                        autoFocus
                        onChange={(e) => setTitle(e.target.value)}
                        value={title}
                    />
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        id="email"
                        label="Email"
                        name="email"
                        autoComplete="email"
                        autoFocus
                        onChange={(e) => setEmail(e.target.value)}
                        value={email}
                    />
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        name="password"
                        label="Password"
                        type="password"
                        id="password"
                        autoComplete="current-password"
                        onChange={(e) => setPassword(e.target.value)}
                        value={password}
                    />
                
                    <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        sx={{ mt: 3, mb: 2 }}
                    >
                        Register
                    </Button>
                    <Grid container>
                        <Grid item>
                        <Link to="/register" variant="body2">
                        Already have an account? <Link to="/login">Log in</Link>
                        </Link>
                        </Grid>
                    </Grid>
                    </Box>
                </Box>
                </Container>
            </ThemeProvider>
  
      {/* <div className="container">
        <div className="row">
          <div className="col s8 offset-s2">
            <Link to="/" className="btn-flat waves-effect">
              <i className="material-icons left">keyboard_backspace</i> Back to
              home
            </Link>
            <div className="col s12" style={{ paddingLeft: "11.250px" }}>
              <h4>
                <b>Register</b> below
              </h4>
              <p className="grey-text text-darken-1">
                Already have an account? <Link to="/login">Log in</Link>
              </p>
            </div>
            <form noValidate onSubmit={onSubmit}>
              <div className="input-field col s12">
                <input
                  // onChange={this.onChange}
                  // value={this.state.first_name}
                  // error={errors.first_name}
                  id="first_name"
                  type="text"
                />
                <label htmlFor="first_name">First Name</label>
              </div>
              <div className="input-field col s12">
                <input
                  // onChange={this.onChange}
                  // value={this.state.last_name}
                  // error={errors.last_name}
                  id="last_name"
                  type="text"
                />
                <label htmlFor="last_name">Last Name</label>
              </div>
              <div className="input-field col s12">
                <input
                  // onChange={this.onChange}
                  // value={this.state.title}
                  // error={errors.title}
                  id="title"
                  type="text"
                />
                <label htmlFor="title">Title</label>
              </div>
              <div className="input-field col s12">
                <input
                  // onChange={this.onChange}
                  // value={this.state.email}
                  // error={errors.email}
                  id="email"
                  type="email"
                />
                <label htmlFor="email">Email</label>
              </div>
              <div className="input-field col s12">
                <input
                  // onChange={this.onChange}
                  // value={this.state.password}
                  // error={errors.password}
                  id="password"
                  type="password"
                />
                <label htmlFor="password">Password</label>
              </div>
              <div className="col s12" style={{ paddingLeft: "11.250px" }}>
                <button
                  style={{
                    width: "150px",
                    borderRadius: "3px",
                    letterSpacing: "1.5px",
                    marginTop: "1rem"
                  }}
                  type="submit"
                  className="btn btn-large waves-effect waves-light hoverable blue accent-3"
                >
                 Sign up
                </button>
              </div>
            </form>
          </div>
        </div>
      </div> */}
      </>
    );

}
export default Register;