import os, datetime

from flask import Flask
from flask_smorest import Api
from db import db
from dotenv import load_dotenv

from flask_jwt_extended import JWTManager

from resources.user import blp as UserBlueprint
from resources.client import blp as ClientBlueprint
from resources.appointment import blp as AppointmentBlueprint
from resources.follow_up import blp as FollowUpBlueprint

def create_app(db_url=None):
    app = Flask(__name__)
    load_dotenv()

    app.config["PROPAGATE_EXCEPTIONS"] = True
    app.config["API_TITLE"] = "Stores REST API"
    app.config["API_VERSION"] = "v1"
    app.config["OPENAPI_VERSION"] = "3.0.3"
    app.config["OPENAPI_URL_PREFIX"] = "/"
    app.config["OPENAPI_SWAGGER_UI_PATH"] = "/api-docs"
    app.config["OPENAPI_SWAGGER_UI_URL"] = "https://cdn.jsdelivr.net/npm/swagger-ui-dist/"
    # Connect to the database
    app.config["SQLALCHEMY_DATABASE_URI"] = db_url or os.getenv("DATABASE_URL", "sqlite:///data.db")
    app.config["SQLALCHEMY_TRACK_MODIFICATION"] = False
    db.init_app(app)

    api = Api(app)

    app.config["JWT_SECRET_KEY"] = "174256156345412616362974167403801169277"
    app.config["JWT_ACCESS_TOKEN_EXPIRES"] = datetime.timedelta(hours=int(os.getenv("JWT_ACCESS_TOKEN_EXPIRES")))
    jwt = JWTManager(app)

    @app.before_first_request
    def create_tables():
        db.create_all()

    api.register_blueprint(UserBlueprint)
    api.register_blueprint(ClientBlueprint)
    api.register_blueprint(AppointmentBlueprint)
    api.register_blueprint(FollowUpBlueprint)

    return app
