from db import db

class UserClientModel(db.Model):
    __tablename__ = "user_client"

    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("client.id"), primary_key=True)

