import React, { useState, useEffect} from 'react';
import bc from '../layout/Images/i1.png';
import { Link } from 'react-router-dom';
import "./Home.css";
import "./Clients.css";
import ClientDashboard from '../client_ui/clientDashboard';
import axios  from 'axios';

const Clients = () => {
    const [ searchText, setSearchText ] = useState("");
    const [ searchedResult, setSearchedResult ] = useState([]);

    const [ isAdvanceFilterClicked, setIsAdvancedFilterClicked ] = useState(false);

    const [ emailFilterStatus, setEmailFilterStatus ] = useState(false)
    const [ firstNameStatus, setFirstNameFilterStatus ] = useState(false)
    const [ lastNameFilterStatus, setLastNameFilterStatus ] = useState(false)

    let access_token = sessionStorage.getItem('access_token');

    let delay;

    const fetchClients = async()=> {
        console.log('call Api',searchText)
        let isAnyOfEmailFirstNameOrLastNameEmpty = true
        let params = {}
        if(emailFilterStatus){
            params['email'] = searchText;
            isAnyOfEmailFirstNameOrLastNameEmpty = false
        }
        if(firstNameStatus){
            params['first_name'] = searchText
            isAnyOfEmailFirstNameOrLastNameEmpty = false
        }
        if(lastNameFilterStatus){
            params['last_name'] = searchText
            isAnyOfEmailFirstNameOrLastNameEmpty = false
        }

        if(isAnyOfEmailFirstNameOrLastNameEmpty){
            params['name'] = searchText
        }
        // else{
        //     params['name'] = searchText
        // }
        console.log("paras", params)

        await axios.get("/councilor/client",{params: params, headers: {"Authorization" : `Bearer ${access_token}`} })
        .then(res => {
            if(res.status === 200){
                console.log("clientres",res)
                setSearchedResult(res.data)
            }
        })
        .catch(err => console.log("error in fetching clients"))
    
        // if(searchText){
        //     await axios.get("/councilor/client",{params: params, headers: {"Authorization" : `Bearer ${access_token}`} })
        //     .then(res => {
        //         if(res.status === 200){
        //             console.log("clientres",res)
        //             setSearchedResult(res.data)
        //         }
        //     })
        //     .catch(err => console.log("error in fetching clients"))
        // }
        // else{
        //     axios.get('/councilor/client', { headers: {"Authorization" : `Bearer ${access_token}`} })
        //     .then(res => {
        //         if(res.status === 200){
        //             setSearchedResult(res.data)
        //         }
        //     })
        // }
       
      }

      useEffect(() => {
        fetchClients()
      },[])

      useEffect(() => {
        

       if(searchText){
            delay = setTimeout(() => {
            if(searchText)fetchClients()
          }, 1000)
          return () => clearTimeout(delay)
       }
       else{
        fetchClients()
       }
   
      
     }, [searchText])
   
     const keyDown = (e)=>{
       if (e.key === "Enter") {
         clearTimeout(delay)
         fetchClients()
         console.log('keyDown press and ready for api call')
       }
     }

        return (
            <div className="container">
                {/* <div id="navbar">
                    <div class="left-section">
                        <img src={bc} alt="pic" />
                    </div>
                    <div class="right-section">
                        <ul>
                            <li>
                                <Link to="/home">Home</Link>
                            </li>
                            <li>
                                <Link to="/clients">Clients</Link>
                            </li>
                            <li>
                                <Link to="/">Appointments</Link>
                            </li>
                            <li>
                                <Link to="/">Reminders</Link>
                            </li>
                            <li>
                                <Link to="/">Account</Link>
                            </li>
                        </ul>
                    </div>
                </div> */}
                <div className='dashboard-menus-main'>
                    <div>
                        <p>Counciler:</p>
                        <button>YOU</button>
                    </div>

                    <div className='menubar-searchbar-main'>
                        <input type="text" placeholder=' Search Name, Email, First Name, Last Name'
                            value={searchText} onChange={(e) => setSearchText(e.target.value)}
                            onKeyDown={keyDown} className="search-bar-input"
                        />
                        <p onClick={() => setIsAdvancedFilterClicked(!isAdvanceFilterClicked)}
                           className={isAdvanceFilterClicked ? "advance-filter-active" : "advance-filter"}
                        >
                            Advance Filters
                        </p>
                        {isAdvanceFilterClicked && (
                            <div className='advance-filer-main'>
                                <input type="checkbox" 
                                    className='advance-filter-input' 
                                    id="email" 
                                    name="email"
                                    value={emailFilterStatus} 
                                    onChange={(e) =>  setEmailFilterStatus(e.target.checked) } />
                                <label for="email" className='filter-menu-input-label'> Email</label>
            
                                <input type="checkbox" 
                                    className='advance-filter-input' 
                                    id="firstName" 
                                    name="firstName" 
                                    value={firstNameStatus}
                                    onChange={(e) =>  setFirstNameFilterStatus(e.target.checked)}
                                    />
                                <label for="firstName" className='filter-menu-input-label'> First Name</label>
            
                                <input type="checkbox" 
                                    className='advance-filter-input' 
                                    id="lastName" 
                                    name="lastName" 
                                    value={lastNameFilterStatus}
                                    onChange={(e) =>  setLastNameFilterStatus(e.target.checked)}
                                    />
                                <label for="lastName" className='filter-menu-input-label'> Last Name</label>
                            </div>
                        )}
                        
                    </div>

                    <div>
                        <div className="create">
                            <Link to="/clientCreate">+create</Link>
                        </div>
                    </div>
                </div>
                
                <div>

                    <ClientDashboard searchedResult={searchedResult}/>
                </div>
            </div>
        )
}

export default Clients;