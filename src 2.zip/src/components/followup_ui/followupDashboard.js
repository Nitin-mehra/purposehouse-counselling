import React from 'react';
import '../style/clientDashboard.css'

const FollowupDashboard = (props) => {

        
    return(
        <>

            {props.searchedResult.map(followup => {
                            console.log("check",followup)
                            return(
                                <div className='main-card'>
                            <div>
                                <h1> {followup.title}</h1>
                            </div>

                            {/* <div className='client-dashboard-buttons'> */}
                                {/* <Link to="/followupCreate"> */}
                                    {/* <button className='client-btn'>Create Feedback</button> */}
                                {/* </Link>    */}
                            {/* </div> */}
                        </div>
                            )
                        })}
        </>
    )
}

export default FollowupDashboard;